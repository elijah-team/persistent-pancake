package tripleo.elijah.nextgen.outputtree;

public enum EOT_OutputType {
    SOURCES, LOGS
}
